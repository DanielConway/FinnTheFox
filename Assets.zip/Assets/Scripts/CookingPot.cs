﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CookingPot : MonoBehaviour
{
    public Slider slider;

    public GameObject spot1, spot2;
    public GameObject item1, item2;

    public bool isActive = false;

    public GameObject overlay;

    public float timeToCook;

    public GameObject[] craftingDrops;

    public Animator anim;

    public ParticleSystem ps;

    Player player;

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
    }

    private void OnMouseOver()
    {
        overlay.SetActive(true);
    }

    private void OnMouseExit()
    {
        if (item1 == null && item2 == null) {
            overlay.SetActive(false);
        }
        
    }

    public void StartCooking() {

        if (item1 != null && item2 != null) {
            ps.Play();
            StartCoroutine(CookingTime(timeToCook));

        }

    }

    IEnumerator CookingTime(float timeLeft) {

        anim.SetBool("isCooking", true);
        if(timeLeft <= 0)
        {
            DoneCooking();
            yield return null;

        }

        yield return new WaitForSeconds(.1f);
        slider.value = slider.value - (1 * (.1f / timeToCook));

        if (timeLeft > 0) {
            StartCoroutine(CookingTime(timeLeft - 0.1f));
        }

    }

    void DoneCooking() {

        if (player.isTutorial)
        {
            player.GetComponent<Tutorial>().Done4();
        }

        this.gameObject.GetComponent<AudioSource>().Play();

        anim.SetBool("isCooking", false);
        //both are apples, drop apple pie
        if ((item1.GetComponent<Drop>().itemName == "Apple" && item2.GetComponent<Drop>().itemName == "Apple")) {

            Instantiate(craftingDrops[0], this.transform.position + (Vector3.up * 5) + (Vector3.left * 2), Quaternion.identity, null);

            PotReset();

        }

        //water buckets, bottled water
        else if ((item1.GetComponent<Drop>().itemName == "Water Bucket" && item2.GetComponent<Drop>().itemName == "Water Bucket"))
        {

            Instantiate(craftingDrops[1], this.transform.position + (Vector3.up * 5) + (Vector3.left * 2), Quaternion.identity, null);

            PotReset();

        }

        //aplle and water, apple juice
        else if ((item1.GetComponent<Drop>().itemName == "Water Bucket" && item2.GetComponent<Drop>().itemName == "Apple") ||
            (item1.GetComponent<Drop>().itemName == "Apple" && item2.GetComponent<Drop>().itemName == "Water Bucket"))
        {

            Instantiate(craftingDrops[2], this.transform.position + (Vector3.up * 5) + (Vector3.left * 2), Quaternion.identity, null);

            PotReset();

        }

        //apple and fish, smoked fish
        else if ((item1.GetComponent<Drop>().itemName == "Fish" && item2.GetComponent<Drop>().itemName == "Apple") ||
            (item1.GetComponent<Drop>().itemName == "Apple" && item2.GetComponent<Drop>().itemName == "Fish"))
        {

            Instantiate(craftingDrops[3], this.transform.position + (Vector3.up * 5) + (Vector3.left * 2), Quaternion.identity, null);

            PotReset();

        }

        //apple and cherry, smoked fish
        else if ((item1.GetComponent<Drop>().itemName == "Cherry" && item2.GetComponent<Drop>().itemName == "Apple") ||
            (item1.GetComponent<Drop>().itemName == "Apple" && item2.GetComponent<Drop>().itemName == "Cherry"))
        {

            Instantiate(craftingDrops[4], this.transform.position + (Vector3.up * 5) + (Vector3.left * 2), Quaternion.identity, null);

            PotReset();

        }

        //fish and water, bad water
        else if ((item1.GetComponent<Drop>().itemName == "Fish" && item2.GetComponent<Drop>().itemName == "Water Bucket") ||
            (item1.GetComponent<Drop>().itemName == "Water Bucket" && item2.GetComponent<Drop>().itemName == "Fish"))
        {

            Instantiate(craftingDrops[5], this.transform.position + (Vector3.up * 5) + (Vector3.left * 2), Quaternion.identity, null);

            PotReset();

        }

        //Cherry and cherry, smoked fish
        else if ((item1.GetComponent<Drop>().itemName == "Cherry" && item2.GetComponent<Drop>().itemName == "Cherry"))
        {

            Instantiate(craftingDrops[6], this.transform.position + (Vector3.up * 5) + (Vector3.left * 2), Quaternion.identity, null);

            PotReset();

        }

        //apple and cherry, smoked fish
        else if ((item1.GetComponent<Drop>().itemName == "Fish" && item2.GetComponent<Drop>().itemName == "Fish"))
        {

            Instantiate(craftingDrops[7], this.transform.position + (Vector3.up * 5) + (Vector3.left * 2), Quaternion.identity, null);

            PotReset();

        }

        //apple and cherry, smoked fish
        else if ((item1.GetComponent<Drop>().itemName == "Cherry" && item2.GetComponent<Drop>().itemName == "Fish") ||
            (item1.GetComponent<Drop>().itemName == "Fish" && item2.GetComponent<Drop>().itemName == "Cherry"))
        {

            Instantiate(craftingDrops[8], this.transform.position + (Vector3.up * 5) + (Vector3.left * 2), Quaternion.identity, null);

            PotReset();

        }

        //water and cherry, cherryWater
        else if ((item1.GetComponent<Drop>().itemName == "Cherry" && item2.GetComponent<Drop>().itemName == "Water Bucket") ||
            (item1.GetComponent<Drop>().itemName == "Water Bucket" && item2.GetComponent<Drop>().itemName == "Cherry"))
        {

            Instantiate(craftingDrops[9], this.transform.position + (Vector3.up * 5) + (Vector3.left * 2), Quaternion.identity, null);

            PotReset();

        }
    }

    public void PotReset() {

        Destroy(item1);
        Destroy(item2);
        item1 = null;
        item2 = null;

        overlay.SetActive(false);
        slider.value = 1;
    }
}
