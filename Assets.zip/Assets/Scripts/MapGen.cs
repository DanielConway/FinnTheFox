﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapGen : MonoBehaviour
{
    public int mapSize;

    public GameObject[] resources;

    public int resourceAmount;

    public GameObject[] backgroundElements;
    public int bgAmount;
    
    // Start is called before the first frame update
    void Start()
    {
        populateBG();
        populateMap();

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void populateMap() {

        //runs through every resource
        for (int i = 0; i < resourceAmount; i++)
        {
            int randX = Random.Range(-mapSize, mapSize);
            int randY = Random.Range(-mapSize, mapSize);

            int randRes = Random.Range(0, resources.Length);

            if (Mathf.Abs(randX) > 20 || Mathf.Abs(randY) > 20) {
                Instantiate(resources[randRes], new Vector2(randX, randY), Quaternion.identity, this.transform);
            }
            

        }

    }

    void populateBG()
    {

        //runs through every resource
        for (int i = 0; i < bgAmount; i++)
        {
            int randX = Random.Range(-mapSize, mapSize);
            int randY = Random.Range(-mapSize, mapSize);

            int randRes = Random.Range(0, backgroundElements.Length);

            if (Mathf.Abs(randX) > 3 || Mathf.Abs(randY) > 3)
            {
                Instantiate(backgroundElements[randRes], new Vector2(randX, randY), Quaternion.identity, this.transform);
            }


        }

    }
}
