﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Pet : MonoBehaviour
{
    public float tickRate;

    public float foodValue, waterValue;

    public int maxFoodValue, maxWaterValue;

    public Slider foodSlider, WaterSlider;

    public float consumptionRate;

    Player player;

    public AudioSource[] feedingSounds;

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
        StartCoroutine(ConsumeResources());
    }

    IEnumerator ConsumeResources() {

        if (player.isDead == true) {
            yield return null;
        }

        yield return new WaitForSeconds(tickRate);
        ConsumeTick();

        foodSlider.value = foodValue / maxFoodValue;
        WaterSlider.value = waterValue / maxWaterValue;

        //low states
        if (foodSlider.value <= .4f || WaterSlider.value <= .4f) {

            player.FoxIsLow();

        }

        //not low states
        if (foodSlider.value > .4f && WaterSlider.value > .4f)
        {
            
            player.FoxIsNotLow();

        }

        
        //death states
        if (waterValue <= 0) {

            player.isDead = true;
            player.PlayerDeath("Water");

        }

        if (foodValue <= 0)
        {

            player.isDead = true;
            player.PlayerDeath("Food");

        }

        if (player.isPaused == false && player.isDead == false)
        {
            StartCoroutine(ConsumeResources());
        }

        else if (player.isPaused == true && player.isDead == false) {

            StartCoroutine(CheckToUnpause());

        }

    }

    IEnumerator CheckToUnpause() {

        yield return new WaitForSeconds(0.1f);
        if (player.isPaused == false) {
            StartCoroutine(ConsumeResources());
        }

        if (player.isPaused == true)
        {
            StartCoroutine(CheckToUnpause());
        }

    }

    void ConsumeTick() {

        foodValue = foodValue - (1 * consumptionRate);
        waterValue = waterValue - (0.75f * consumptionRate);

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log(collision.name);
    }

    public void PlayFeedingSound() {

        int rand = Random.Range(0, feedingSounds.Length);

        feedingSounds[rand].Play();

    }
}
