﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GuideArrow : MonoBehaviour
{
    public GameObject target;
    public float threshold;
    public GameObject arrowGFX;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //if its far away, show the arrow

        if(Mathf.Abs((this.gameObject.transform.position - target.transform.position).magnitude) > threshold){

            arrowGFX.SetActive(true);

            Vector3 targetAngle = target.transform.position;
            targetAngle.z = 0f;
            targetAngle.x = targetAngle.x - this.gameObject.transform.position.x;
            targetAngle.y = targetAngle.y - this.gameObject.transform.position.y;

            float angle = Mathf.Atan2(targetAngle.x, targetAngle.y) * Mathf.Rad2Deg;


            this.gameObject.transform.rotation = Quaternion.Euler(new Vector3(0, 0, -angle));
        }

        if (Mathf.Abs((this.gameObject.transform.position - target.transform.position).magnitude) < threshold)
        {

            arrowGFX.SetActive(false);

            Vector3 targetAngle = target.transform.position;
            targetAngle.z = 0f;
            targetAngle.x = targetAngle.x - this.gameObject.transform.position.x;
            targetAngle.y = targetAngle.y - this.gameObject.transform.position.y;

            float angle = Mathf.Atan2(targetAngle.x, targetAngle.y) * Mathf.Rad2Deg;


            this.gameObject.transform.rotation = Quaternion.Euler(new Vector3(0, 0, -angle));
        }



    }
}
