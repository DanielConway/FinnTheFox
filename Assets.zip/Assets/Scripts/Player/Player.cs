﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    public GameObject currentDragging;

    public GameObject[] playerInventory;

    public GameObject nextFreeSpot = null;

    public GameObject fox;
    private Animator foxAnim;

    public bool isDead = false;
    public GameObject deadScreen;

    float timeIntoGame = 0;

    public Text timeTxt, reasonTxt;

    public bool isPaused = false;
    public GameObject pauseMenu;

    public bool isTutorial;

    public float secondsToWin;

    public GameObject winPanel;

    private void Start()
    {
        foxAnim = fox.GetComponent<Animator>();
    }

    private void FixedUpdate()
    {
        if (isDead == false && isPaused == false) {
            timeIntoGame += Time.fixedDeltaTime;

            if (timeIntoGame >= secondsToWin) {
                isPaused = true;

                if (isTutorial) {
                    this.gameObject.GetComponent<Tutorial>().Done5();
                }
                WinGame();
            }
        }
        
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape) && isPaused == false) {
            isPaused = true;
            pauseMenu.SetActive(true);
        }

        else if (Input.GetKeyDown(KeyCode.Escape) && isPaused == true)
        {
            isPaused = false;
            pauseMenu.SetActive(false);
        }
    }

    public void isFreeInvSpot() {

        foreach (GameObject spot in playerInventory) {

            if (spot.gameObject.GetComponent<InventorySpot>().hasObject == false) {
                nextFreeSpot = spot;
                return;
            }

        }

    }

    public void FoxHappy() {

        foxAnim.ResetTrigger("isHappy");

        foxAnim.SetTrigger("isHappy");
    }

    public void FoxIsLow() {

        foxAnim.SetBool("isLow", true);
    }

    public void FoxIsNotLow()
    {
        foxAnim.SetBool("isLow", false);

    }

    public void PlayerDeath(string reason) {

        isPaused = true;
        deadScreen.SetActive(true);
        timeTxt.text = "You Kept Finn Alive for: " + (int)timeIntoGame + " Seconds!";
        reasonTxt.text = "He ran out of " + reason + ".";
    }

    public void UnPause() {

        isPaused = false;
        pauseMenu.SetActive(false);
    }

    public void PlayAgain() {

        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

    }

    public void ToMenu()
    {

        SceneManager.LoadScene(0);

    }

    void WinGame() {

        winPanel.SetActive(true);
    }

    public void NextScene() {
        
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

}
