﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    Vector3 moveDir;
    public float speed;

    Vector3 lastPos;
    Player player;

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
    }
    /*
    //keyboard movement
    void Update()
    {
        moveDir = Vector3.zero;
        if (Input.GetAxis("Horizontal") > 0) {
            //move right
            moveDir.x += speed * Time.deltaTime;
        }

        if (Input.GetAxis("Horizontal") < 0)
        {
            //move left
            moveDir.x -= speed * Time.deltaTime;
        }

        if (Input.GetAxis("Vertical") > 0)
        {
            //move up
            moveDir.y += speed * Time.deltaTime;
        }

        if (Input.GetAxis("Vertical") < 0)
        {
            //move down
            moveDir.y -= speed * Time.deltaTime;
        }

        this.gameObject.transform.position += moveDir;

    }
    */

    private void Update()
    {
        if (Input.GetMouseButtonDown(0) && player.isPaused == false) {

            lastPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        }

        if (Input.GetMouseButton(0) && player.currentDragging == null && player.isPaused == false) {

            if (player.isTutorial) {
                player.GetComponent<Tutorial>().Done1();
            }
            Vector3 dir = lastPos - Camera.main.ScreenToWorldPoint(Input.mousePosition);
            this.gameObject.transform.position += dir;

        }
    }

}
