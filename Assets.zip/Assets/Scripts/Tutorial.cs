﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tutorial : MonoBehaviour
{
    public GameObject[] checkMarks;

    public bool[] tasks;

    bool isDone = false;

    private void Start()
    {
        tasks = new bool[5];
    }

    public void Done1() {
        tasks[0] = true;
        checkMarks[0].SetActive(true);
    }

    public void Done2()
    {
        tasks[1] = true;
        checkMarks[1].SetActive(true);
    }

    public void Done3()
    {
        tasks[2] = true;
        checkMarks[2].SetActive(true);
    }

    public void Done4()
    {
        tasks[3] = true;
        checkMarks[3].SetActive(true);
    }

    public void Done5()
    {
        tasks[4] = true;
        checkMarks[4].SetActive(true);
    }

    void CheckForDone() {

        if (tasks[0] == true && tasks[1] == true && tasks[2] == true && tasks[3] == true && tasks[4] == true) {

            isDone = true;

        }

    }
}
