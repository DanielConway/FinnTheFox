﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Drop : MonoBehaviour
{
    bool isDragging = false;
    Player player;

    bool isInInventory = false;
    InventorySpot invSpot;

    public string itemName;
    public string itemType;
    public int itemValue;

    public GameObject tooltip;
    public Text titleTxt, valueTxt;

    bool isEating = false;

    bool isInCookPot = false;

    public bool crafted;

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();

        SetUpTooltip();
    }

    
    void Update()
    {
        if (isDragging == true) {

            Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition) - this.gameObject.transform.position;
            this.gameObject.transform.Translate(mousePosition);

        }
    }

    
    private void OnMouseDown()
    {

        if (isInCookPot == false) {
            isDragging = true;

            UpgradeOrder();

            player.currentDragging = this.gameObject;
            HideTooltip();
        }
        
    }

    private void OnMouseOver()
    {
        //Explicitly for tooltip
        if (isDragging == false && isEating == false) {
            ShowTooltip();
        }

        if (isEating) {
            HideTooltip();
        }
    }

    private void OnMouseExit()
    {
        HideTooltip();
    }

    private void OnMouseUp()
    {
        isDragging = false;
        player.currentDragging = null;

        RaycastHit2D[] hits;
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        hits = Physics2D.GetRayIntersectionAll(Camera.main.ScreenPointToRay(Input.mousePosition));

        bool foundAnInventorySpot = false;

        foreach (RaycastHit2D hit in hits) {
            
            //feed to pet
            if (hit.collider.gameObject.CompareTag("Pet")) {

                if (player.isTutorial && itemName == "Apple") {
                    player.GetComponent<Tutorial>().Done3();
                }

                if (invSpot != null) {
                    invSpot.hasObject = false;
                    invSpot.currentObject = null;
                    invSpot = null;
                }
                isInInventory = false;

                Pet pet = hit.collider.gameObject.GetComponent<Pet>();

                if (itemType == "Food") {
                    pet.foodValue += itemValue;
                    if (pet.foodValue > pet.maxFoodValue)
                    {

                        pet.foodValue = pet.maxFoodValue;

                    }
                }

                if (itemType == "Water")
                {
                    pet.waterValue += itemValue;
                    if (pet.waterValue > pet.maxWaterValue) {

                        pet.waterValue = pet.maxWaterValue;

                    }
                }

                player.FoxHappy();

                this.transform.parent = null;

                pet.PlayFeedingSound();
                StartCoroutine(EatingAnim());

            }

            //place in inventory
            if (hit.collider.gameObject.CompareTag("InventorySpot") && hit.collider.gameObject.GetComponent<InventorySpot>().hasObject == false)
            {

                if (player.isTutorial) {

                    player.GetComponent<Tutorial>().Done2();

                }

                foundAnInventorySpot = true;

                InventorySpot iSpot = hit.collider.gameObject.GetComponent<InventorySpot>();
                invSpot = iSpot;
                iSpot.hasObject = true;
                iSpot.currentObject = this.gameObject;
                this.gameObject.transform.parent = iSpot.transform;
                this.gameObject.transform.position = iSpot.transform.position;

                this.gameObject.GetComponent<Animator>().enabled = false;

                isInInventory = true;
            }

            //if placing in cooking pot
            if (hit.collider.gameObject.CompareTag("CraftingPot") && isInCookPot == false && crafted == false) {


                isInCookPot = true;

                CookingPot cp = hit.collider.gameObject.GetComponent<CookingPot>();
                if (cp.item1 == null)
                {
                    cp.item1 = this.gameObject;
                    this.gameObject.transform.parent = cp.spot1.transform;
                    this.gameObject.transform.position = cp.spot1.transform.position;
                }

                else if (cp.item2 == null)
                {
                    cp.item2 = this.gameObject;
                    this.gameObject.transform.parent = cp.spot2.transform;
                    this.gameObject.transform.position = cp.spot2.transform.position;
                }

                else if (cp.isActive) {
                    break;
                }

                //START COOKING!
                if (cp.item1 != null && cp.item2 != null && cp.isActive == false) {
                    cp.StartCooking();
                }

                this.gameObject.GetComponent<Animator>().enabled = false;
                invSpot.hasObject = false;
                isInInventory = false;


            }

            
            
        }

        //take out of inventory and drop on ground
        if (foundAnInventorySpot == false && isInInventory == true && isInCookPot == false) {

            Debug.Log("DROPPED");
            ResetOrder();

            isInInventory = false;
            invSpot.hasObject = false;
            invSpot.currentObject = null;
            invSpot = null;
            this.gameObject.transform.parent = null;

        }

    }

    IEnumerator EatingAnim() {
        isEating = true;
        
        HideTooltip();
        this.gameObject.GetComponent<Animator>().enabled = true;
        this.gameObject.GetComponent<Animator>().SetTrigger("isEating");
        
        yield return new WaitForSeconds(1f);
        Destroy(this.gameObject);
    }

    void SetUpTooltip() {
        titleTxt.text = itemName;

        if (itemType == "Food")
        {
            valueTxt.color = new Color32(233, 69 , 73, 255);
        }

        if (itemType == "Water")
        {
            valueTxt.color = new Color(16 / 255, 144 / 255, 255 / 255);
        }

        valueTxt.text = "+" + itemValue;
    }

    void ShowTooltip() {

        tooltip.SetActive(true);
        
    }

    void HideTooltip() {

        tooltip.SetActive(false);
        
    }

    void UpgradeOrder() {

        SpriteRenderer [] rends = this.gameObject.GetComponentsInChildren<SpriteRenderer>();
        foreach (SpriteRenderer r in rends) {

            if (r.gameObject.CompareTag("Tooltip"))
            {
                r.sortingOrder = 502;
            }
            if (r.gameObject.name == "shadow") {
                r.sortingOrder = 500;
            }
            if (r.gameObject.transform.parent.name == "Canvas") {
                Debug.Log(gameObject.name);
                r.sortingOrder = 503;
            }
            else
            {
                r.sortingOrder = 501;
            }
            
        }

        


    }

    void ResetOrder()
    {

        SpriteRenderer[] rends = this.gameObject.GetComponentsInChildren<SpriteRenderer>();
        foreach (SpriteRenderer r in rends)
        {
            if (r.gameObject.CompareTag("Tooltip"))
            {
                r.sortingOrder = 101;
            }
            if (r.gameObject.name == "shadow")
            {
                r.sortingOrder = 99;
            }
            else
            {
                r.sortingOrder = 100;
            }
        }

    }

}
