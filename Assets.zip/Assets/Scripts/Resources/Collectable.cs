﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Collectable : MonoBehaviour
{
    public float timeToHarvest;
    bool harvesting = false;

    private Slider slider;
    private GameObject barCanvas;

    public GameObject drop, secondaryDrop;

    public string type;

    public ParticleSystem ps;

    private void Start()
    {
        slider = gameObject.GetComponentInChildren<Slider>();
        barCanvas = gameObject.GetComponentInChildren<Canvas>().gameObject;
        barCanvas.SetActive(false);
    }

    private void OnMouseDown()
    {
        if (harvesting == false) {
            harvesting = true;
            barCanvas.SetActive(true);
            ps.Play();
            StartCoroutine(Countdown(timeToHarvest));
        }
    }

    IEnumerator Countdown(float timeLeft) {
        timeLeft = timeLeft - (timeToHarvest / 100);
        yield return new WaitForSeconds(timeToHarvest/100);
        slider.value = slider.value - 0.01f;
        if (timeLeft > 0) {
            StartCoroutine(Countdown(timeLeft));
        }
        if (timeLeft <= 0) {

            if (type == "Pond") {

                int randChance = Random.Range(0, 100);

                //happens 33% of the time
                if (randChance > 20) {
                    Instantiate(secondaryDrop, this.transform.position + (Vector3.down * 4) + (Vector3.right * 3), Quaternion.identity, null);
                }

            }


            if (this.gameObject.CompareTag("RegenResource"))
            {
                PlaySound();
                Instantiate(drop, this.transform.position + (Vector3.down * 4), Quaternion.identity, null);
                harvesting = false;
                slider.value = 1;
                barCanvas.SetActive(false);
                
            }

            else if (this.gameObject.CompareTag("SemiRegenResource"))
            {
                int rand = Random.Range(0, 100);
                PlaySound();
                Instantiate(drop, this.transform.position + (Vector3.down * 4), Quaternion.identity, null);

                Debug.Log(rand);
                //1 in 4 chance to break
                if (rand < 25)
                {
                    StartCoroutine(GoAway());
                }

                else {
                    harvesting = false;
                    slider.value = 1;
                    barCanvas.SetActive(false);
                }
            }

            else {
                PlaySound();
                Instantiate(drop, this.transform.position, Quaternion.identity, null);
                StartCoroutine(GoAway());
            }
            
        }

    }

    private void PlaySound() {

        this.gameObject.GetComponent<AudioSource>().Play();
    }

    private IEnumerator GoAway() {

        this.gameObject.GetComponent<Animator>().SetTrigger("GoAway");
        yield return new WaitForSeconds(0.5f);
        Destroy(this.gameObject);
    }
}
